%% ͼƬ��ʽ

set(gca,'fontsize',15,'fontweight','bold');
title('��ͬ��ȶ�Ӧ�ĶԱȶ�');
xlabel('Thickness (nm)');
ylabel('Contrast');
box on
L = findobj(gca,'Type','Line');
set(L,'linewidth',1.5);
%% ֻ�ı���

Thickness = [20000, 2, 47,  3.5, 0, 10000];
n = [1.51361, 3.06769 + 3.36054i, 0.16146 + 3.64199i, 1.33, 1.48, 1.36];
d = zeros(6,40);
for ii = 1:size(d,2)
    d(:,ii) = Thickness';
    d(5,ii) = 0.1*(ii-1);
end
theta = 74*pi/180;
lambda = 670;
R1 = zeros(size(d,2),1);
figure
hold on
for ii = 1:size(d,2)
	R1(ii) = MultiLayerReflect(lambda,theta,n,d(:,ii));
end
plot(d(5,:),(R1-R1(1))/R1(1))
% plot(d(5,:),R1)
%%
% ϵͳ��ɺͺ��ȷ����ֻ�ı�Ƕ�
clear
d = [20000, 2, 47, 3.5, 4, 100000];
n = [1.51361, 3.06769 + 3.36054i, 0.16146 + 3.64199i, 1.36, 1.48, 1.36];
theta = [70:0.1:80]'*pi/180;
lambda = 670;
R1 = zeros(size(theta,1),1);
for ii = 1:size(theta,1)
	R1(ii) = MultiLayerReflect(lambda,theta(ii),n,d);
end
plot(70:0.1:80,R1)

%%  
% ϵͳ���ȷ�����ı��ȺͽǶ�
Thickness = [20000, 2, 47, 3.5, 4, 100000];
n = [1.51361, 3.06769 + 3.36054i, 0.16146 + 3.64199i, 1.36, 1.48, 1.36];
d = zeros(6,4);
for ii = 1:size(d,2)
    d(:,ii) = Thickness';
    d(5,ii) = 1*(ii-1);
end
theta = [70:0.1:80]'*pi/180;
lambda = 670;
R1 = zeros(size(theta,1),size(d,2))';
figure
hold on
for ii = 1:size(d,2)
    for jj = 1:size(theta,1)
        R1(ii,jj) = MultiLayerReflect(lambda,theta(jj),n,d(:,ii));
    end
    plot(70:0.1:80,R1(ii,:));
end
% [X,Y] = meshgrid(d(4,:),20:0.1:80);
% mesh(X,Y,R1)

%%  

Thickness = [20000, 2, 50, 100000];
d = zeros(4,100);
for ii = 1:size(d,2)
    d(:,ii) = Thickness';
    d(3,ii) = 1*ii;
end
n = [1.51361, 3.06769 + 3.36054i, 0.16146 + 3.64199i, 1.36];
theta = (20:0.1:80)'*pi/180;
lambda = 670;
R2 = zeros(size(theta,1),size(d,2));
for ii = 1:size(theta,1)
    for jj = 1:size(d,2)
        R2(ii,jj) = TMM('TM',lambda,theta(ii),n,d(:,jj));
    end
end
[X,Y] = meshgrid(1:100,20:0.1:80);
mesh(X,Y,R2)

%% CAR ��֤

d = [20000, 20000];
N = [1.51361, 1.36];
n = zeros(2,50);
for ii = 1:size(n,2)
    n(:,ii) = N';
    n(2,ii) = 1.333 + ii*(1.5-1.333)/size(n,2);
end
theta = (55:0.01:85)'/180*pi;
lambda = 670;
R = zeros(length(theta),size(n,2));
figure
hold on
for ii = 1:size(n,2)
    for jj = 1:length(theta)
        R(jj,ii) = TMM('TM',lambda,theta(jj),n(:,ii),d);
    end
    plot(R(:,ii));
end

%% ʹ��ITO��Ĥ��ʵ��
clear
D = [20000, 350, 3, 10000];
n = [1.51, 2+0.0043i, 1.45, 1.33];
d = zeros(4,10);
for ii = 1:size(d,2)
    d(:,ii) = D';
    d(3,ii) = ii;
end
theta = (55:0.01:65)'/180*pi;
lambda = 670;
R = zeros(length(theta),size(d,2));
figure
for ii = 1:size(d,2)
    for jj = 1:length(theta)
        R(jj,ii) = TMM('TM',lambda,theta(jj),n,d(:,ii));
    end
    plot(R(:,ii));
    hold on
end

%%
clear
D = [20000, 350, 0, 20000]';
N = [1.51, 2+0.0043i, 1.45, 1.33]';
lambda = 670;
d = zeros(length(D),10);
for ii = 1:size(d,2)
    d(:,ii) = D;
    d(3,ii) = ii;
end
theta = (55:0.1:65)'*pi/180;
figure
hold on
R = zeros(length(theta),size(d,2));
for ii = 1:size(d,2)
    for jj = 1:length(theta)
        R(jj,ii) = TMM('TM',lambda,theta(jj),N,d(:,ii));
    end
    plot(R(:,ii));
end



