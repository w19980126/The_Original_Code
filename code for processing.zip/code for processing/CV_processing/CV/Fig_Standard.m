function Fig_Standard

set(gca,'fontsize',20);
set(gca,'fontweight','bold');
axis square;

end